import os
import shutil
from os import path
from shutil import make_archive

#duplicate a file
if path.exists("newFile.txt"):
    src = path.realpath("newFile.txt")

    #printing the paths etc.
    head,tail = path.split(src)
    print "path: " + head
    print "file: " + tail

    #creating a copy with .bak appended
    dst = src + ".bak"
    shutil.copy(src,dst)

    #copying over all metadata
    shutil.copystat(src, dst)
    root_dir,tail = path.split(src)
    shutil.make_archive("archive", "zip" ,root_dir)

#renaming the file
#os.rename("newFile.txt", "textfile.txt")
#os.rename("textfile.txt", "newFile.txt")

print src
